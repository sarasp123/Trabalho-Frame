import React from "react";
import { Component } from "react";
import './Rodape.css';
    
class Rodape extends Component{
  render(){
    return(
    <div className="rodape">
        <p className="texto1">IFMS Dourados - Trabalho de Frameworks2 - Prof. Ricardo</p>
        <p className="texto2">Sara Silva de Pinho</p>
    </div>
    )
  }
}

export default Rodape